package Interface1;

import java.util.ArrayList;

public interface MenuInterface<T> {
	public ArrayList<T> selecta();
}
