package Interface1;

import java.util.ArrayList;

public interface SanPhamInteface<T> {
	public ArrayList<T> selectAll2();
}
