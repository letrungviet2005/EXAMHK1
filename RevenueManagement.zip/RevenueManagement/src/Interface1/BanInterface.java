package Interface1;

import java.util.ArrayList;

public interface BanInterface<T> {
    public ArrayList<T> selectALLBan();

	
}
