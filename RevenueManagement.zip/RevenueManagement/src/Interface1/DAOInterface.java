package Interface1;
import java.util.ArrayList;
public interface DAOInterface<T> {
        public ArrayList<T> selectAll();
}
